import { Component, OnInit } from '@angular/core';
import { FoodList } from 'src/app/shared/models/foodlist.model';

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.css']
})
export class HomeComponentComponent implements OnInit {

  searchRestaurant: string
  
 
 


  constructor() { 
  
    this.searchRestaurant= ''
    

  }

  ngOnInit(): void {
  }

 
          
  }
  


          
