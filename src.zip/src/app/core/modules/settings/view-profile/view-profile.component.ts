import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { map, Observable } from 'rxjs';
import { IUserFormData } from 'src/app/shared/models/user.models';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {
  public  profileView: IUserFormData;
  
  constructor(private activateRoute: ActivatedRoute, private router : Router ) { 

    this.profileView = {} as IUserFormData
    
   
  }

  public ngOnInit(): void {

    this.activateRoute.paramMap.subscribe((params: any) => {console.log(params);
      
          
      
          this.profileView.lname = params.get('lname'),
          this.profileView.email = params.get('email');
     
    })}
    

  



  GoBack(){
    this.router.navigate(['/user-profile']);
  }

}
