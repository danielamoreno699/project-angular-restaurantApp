
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators  } from '@angular/forms';
import { IUserFormData } from 'src/app/shared/models/user.models';
import { DisablingFormDirective } from 'src/app/shared/directives/user-profile/disabling-form.directive';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ThisReceiver } from '@angular/compiler';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})

export class UserProfileComponent implements OnInit {

  public myForm : FormGroup;


  public userAddress : IUserFormData;
  public userDetails : IUserFormData;


  public isUserFormSubmitted: boolean;

  public isDisabled : boolean;

 
 



  constructor(private formBuilder: FormBuilder, private router : Router) { 
    this.myForm = {} as FormGroup;

    
    this.userAddress = {} as IUserFormData;
    this.userDetails = {} as IUserFormData;

    this.isUserFormSubmitted = false
    this.isDisabled = true

   
    
  }

  ngOnInit(): void {
      this.initializeUserForm()


    }
  
      public initializeUserForm(): void{
      this.myForm = 
      
      this.formBuilder.group({
      
      fname : [''],
      lname : [''],
      email: ['', [Validators.required, Validators.email]],
      password : ['',[Validators.required, Validators.minLength(5),Validators.maxLength(10)]],

      addressGroup :this.formBuilder.group ({
            HouseNo: ['', [Validators.required,  Validators.pattern('[A-Z][a-z][1-9]')]],
            city: [''],
            state: [''],
            landMark: [''] 

             }),
      


      paymentGroup :this.formBuilder.group({
          namePayment: ['', Validators.required],
          creditCard : ['', [Validators.required, Validators.minLength(16), Validators.maxLength(16)]],
          Month: ['', Validators.required, ],
          year: ['', Validators.required],
          cvv: ['', Validators.required, Validators.maxLength(3)]


        })

      })}

      
    get userFormControls(){
      return this.myForm.controls;
    }



      enabling (){
         
      }


      public navigateToViewProfile(){
          this.router.navigate(['/view-profile']);
      }

      public onSubmit1(){
       
       this.isUserFormSubmitted =true

        this.userDetails = this.myForm.get(['email'])?.value, 
        

        this.router.navigate(['/view-profile', {value: JSON.stringify(this.userDetails) }])
      
    
    }

    public onSubmit2(){
      this.isUserFormSubmitted =true


    }

    public onSubmit3(){
      this.isUserFormSubmitted =true

    }






  }



