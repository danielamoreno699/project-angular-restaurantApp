import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-password-reset',
  templateUrl: './user-password-reset.component.html',
  styleUrls: ['./user-password-reset.component.css']
})
export class UserPasswordResetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
