import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticationUserComponent } from './authentication-user/authentication-user.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { UserPasswordResetComponent } from './user-password-reset/user-password-reset.component';


const AuthRoutes: Routes = [

  
 
  {path: 'authentication-user', component: AuthenticationUserComponent},
  {path: 'login-user', component: LoginUserComponent },
  {path: ' user-password-reset', component: UserPasswordResetComponent    }
]




  

@NgModule({
  imports: [RouterModule.forChild(AuthRoutes)],
  exports: [RouterModule]
})
export class AuthenticationRoutingModule { }
