import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators  } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  loginForm: FormGroup;
  submitted: boolean;
  returnUrl : string;

  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute, private router: Router) {

    this.loginForm = {} as FormGroup;
    this.submitted = false;
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/'
  
   }

  ngOnInit(): void {


  }

  


  private initializer(){
    this.loginForm = this.formBuilder.group({
          email: [ '', Validators.required],
          password: ['', Validators.required]


    })
  }

  private log(){
        return this.loginForm.controls
  }

  onSubmit(){
    this.submitted = true
  }




}
