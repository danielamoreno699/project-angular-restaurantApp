import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators  } from '@angular/forms';
import { AuthenticationSService } from 'src/app/core/services/authentication/authentication-s.service';
import { IUserFormData } from 'src/app/shared/models/user.models';
import { MustMatch } from 'src/app/shared/directives/must-match/must-match.validator';



@Component({
  selector: 'app-authentication-user',
  templateUrl: './authentication-user.component.html',
  styleUrls: ['./authentication-user.component.css']
})
export class AuthenticationUserComponent implements OnInit {
  public userForm : FormGroup;
  public userDetails : IUserFormData;
  public isUserFormSubmitted: boolean;
  public isUserRegistered : Boolean

  constructor( private formBuilder: FormBuilder, public authService : AuthenticationSService ) {
     this.userForm = {} as FormGroup;
     this.userDetails = {} as IUserFormData;
     this.isUserFormSubmitted = false;
     this.isUserRegistered = true
   }

  public ngOnInit(): void {
    this.initializeUserForm();
  }

  public initializeUserForm(): void{
    this.userForm = this.formBuilder.group({
      fname : ['', Validators.required],
      lname : ['', Validators.required],
      email: ['', Validators.required, Validators.email],
      password : ['', Validators.required,Validators.minLength(5),Validators.maxLength(10)],
      cpassword :['', Validators.required, Validators.minLength(5),Validators.maxLength(10)],
      disclaimer :[false]


    },{
      validator:MustMatch('password','cpassword')
    }
    
    )   
  
  
  }
    
    get userFormControls(){
      return this.userForm.controls;
    }

    public onSubmit(){
          this.isUserFormSubmitted =true
          this.userDetails = this.userForm.getRawValue();
          this.authService.sendFormDetails( this.userDetails).subscribe((val => {
              console.log(val)
          }))

    }

    public reset():void{
      this.userForm.reset();
  }
  
  
  }
