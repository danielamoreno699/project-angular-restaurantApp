import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthenticationUserComponent } from './authentication-user/authentication-user.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { UserPasswordResetComponent } from './user-password-reset/user-password-reset.component';
import { AuthenticationRoutingModule } from './authentication-routing.module';
import { FormsModule ,ReactiveFormsModule } from '@angular/forms';







@NgModule({
  declarations: [
    AuthenticationUserComponent,
    LoginUserComponent,
    UserPasswordResetComponent
  ],
  imports: [
    CommonModule,
    AuthenticationRoutingModule,
    FormsModule,
    ReactiveFormsModule
   
  ],

  exports:[
    AuthenticationUserComponent,
    LoginUserComponent,
    UserPasswordResetComponent

  ]

})
export class AuthenticationModule { }
