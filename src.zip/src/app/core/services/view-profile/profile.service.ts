import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { IUserFormData } from 'src/app/shared/models/user.models';

export interface profile {


}


export interface ProfileMap{
  
}

@Injectable({
  providedIn: 'root'
})
export class ProfileService {


 

  private userProfile = new Subject<IUserFormData[]>();
  public userProfile$: Observable<IUserFormData[]> = this.userProfile.asObservable();

  public setUserProfile( userProfile: IUserFormData[]) : void{
    this.userProfile.next(userProfile)
  }


  constructor() {

   }


}
