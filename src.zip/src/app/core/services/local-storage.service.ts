import { DialogConfComponent } from 'src/app/shared/components/dialog-conf/dialog-conf.component';
import { Injectable } from '@angular/core';
import { BehaviorSubject, find, from, map, observable, Observable, of, Subject} from 'rxjs';
import { Menu } from 'src/app/shared/models/menu.model';


function getLocalStorage(): Storage {
    return localStorage;
  }

@Injectable({
  providedIn: 'root'
})


export class LocalStorageService {

    get localStorage(): Storage {
        return getLocalStorage();
      }
    
}