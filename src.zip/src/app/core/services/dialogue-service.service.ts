import { DialogConfComponent } from 'src/app/shared/components/dialog-conf/dialog-conf.component';
import { Injectable } from '@angular/core';
import { BehaviorSubject, find, from, map, observable, Observable, of, Subject} from 'rxjs';
import { Menu } from 'src/app/shared/models/menu.model';
import { LocalStorageService } from './local-storage.service';




@Injectable({
  providedIn: 'root'
})



export class DialogueServiceService {
    
  private _localStorage: Storage;

  constructor( private _localStorageRefService: LocalStorageService){
    this._localStorage = _localStorageRefService.localStorage
  }

   private  Menu: Menu[]= []
   private Menu$ : Subject<Menu[]> = new BehaviorSubject<Menu[]>(this.Menu)
   


  private cost: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private dishName: BehaviorSubject<string> = new BehaviorSubject<string>("");
  private count: BehaviorSubject<number> = new BehaviorSubject<number>(0);




    
  public cost$: Observable<number> = this.cost.asObservable();
  public dishName$: Observable<string> = this.dishName.asObservable();
  public count$: Observable<number> = this.count.asObservable();

 

  
  public setCost(cost: number): void {
    this.cost.next(cost);
  }

  public setDishName(dishName: string): void {
    this.dishName.next(dishName);
  }

  public setCount(count: number): void {
    this.count.next(count);
  }


  public getMenuItems() : Observable<Menu[]>{
   return  this.Menu$.asObservable();

  }
  

  public addItem(Menu: Menu): void{
  
        this.Menu.push(Menu);
        
        this.onUpdate()
        console.log(Menu)

  }

  private onUpdate(): void{
    this.Menu$.next(this.Menu)
    

  }


    public addDataToArray(result: Menu)  {

     
      const currentValue = new Array().fill({'key': 'value'});
      const updateValue= [...[currentValue], result];
      console.log(updateValue)

   }


   public removeData(){}

   
 public addToLocalStorage(dataSTorage: any){
  console.log(dataSTorage);

  localStorage.setItem('ObjectMenu', JSON.stringify(dataSTorage))
  this.Menu$.next(dataSTorage)


}
 public loadInfo() {
  const LocalParse = localStorage.getItem('ObjectMenu')
  //const data = JSON.parse(LocalParse)

  //this.Menu$.next(data)
}

}

    //public retrieveData(){

      //let variableRetrieveData=  this.variable.storingData
      //const localRetrieve = {... variableRetrieveData}
      //for (  const item in localRetrieve){
        //    console.log(variableRetrieveData)
      //}
    //}

  
