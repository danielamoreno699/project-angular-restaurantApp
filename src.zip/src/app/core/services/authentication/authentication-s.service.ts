import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IUserFormData } from 'src/app/shared/models/user.models';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationSService {

  constructor(private http: HttpClient) { }


  public sendFormDetails (formData: IUserFormData): Observable <IUserFormData>{
    return this.http.post<IUserFormData>('http://localhost:3000/users', formData)
  }
}
