import { EmailValidator } from "@angular/forms";

export interface IUserFormData{

id : number;
fname : string;
lname : string;
email: EmailValidator;
phone: number;
password: string;
confirmPassword : string;
disclaimer:boolean;  
}

export interface address{

        HouseNo: number;
        city: string;
        state : string; 
        landMark: string

}

export interface payment {

        namePayment: string;
        creditCard: number;
        Month: Date;
        year: Date ;
        cvv : number }

