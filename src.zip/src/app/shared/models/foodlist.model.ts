export interface FoodList{


    
    id: number;
    restaurant: string;
    dishName: string;
    description: string;
    rating: number;
    cost: number;
    imageUrl: string; 
}