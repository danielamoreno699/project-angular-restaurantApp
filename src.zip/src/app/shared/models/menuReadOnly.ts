export interface Menu${

    readonly dishName$ : string;
    readonly cost$: number;
    readonly count$: number
}