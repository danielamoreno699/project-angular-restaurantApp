export interface Menu {
  
    dishName: string;
    cost: number;
    count: number;
  }
  