import { Directive, ElementRef, HostBinding, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHide]'
})
export class HideDirective {
  constructor(private elRef: ElementRef, private renderer2: Renderer2) { }
@Input() visibility: boolean = true
  //(shouldHide) 
   //this.renderer2.setStyle(this.elRef.nativeElement, 'visibility', 'visibility')
   //this.renderer2.removeStyle( this.elRef.nativeElement, 'visibility')



   
@HostListener('click', ['$event.target'])
onClick(){
    this.setStyle(this.visibility)
}



  private setStyle(visibility: boolean){
     this.renderer2.setStyle(this.elRef.nativeElement, 'visibility', 'visibility')
  }

}
