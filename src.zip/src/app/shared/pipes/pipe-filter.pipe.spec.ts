import { PipeFilterPipe } from './pipe-filter.pipe';

describe('PipeFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PipeFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
