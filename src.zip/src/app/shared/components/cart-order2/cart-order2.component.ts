import { Component, OnInit, Input, Inject } from '@angular/core';

import { DialogueServiceService } from 'src/app/core/services/dialogue-service.service';

import { DialogConfComponent } from '../dialog-conf/dialog-conf.component';


import { Menu } from '../../models/menu.model';
import { __await } from 'tslib';
import { combineLatest, forkJoin, map, Observable, Subscription } from 'rxjs';






@Component({
  selector: 'app-cart-order2',
  templateUrl: './cart-order2.component.html',
  styleUrls: ['./cart-order2.component.css']


})


export class CartOrder2Component  implements OnInit{

  public Menu: Menu[] =[]
  public dishName = ''; 
  public cost = 0
  public count = 0
  


  constructor(private dialogs: DialogueServiceService) {}

  
  public  ngOnInit(): void {


    combineLatest([
      this.dialogs.cost$,
      this.dialogs.count$,
      this.dialogs.dishName$,
    ]).pipe(
      map(([ Itemcost, Itemcount, ItemdishName ]: [ number, number, string ])  => {
        
        this.cost = Itemcost
        this.count = Itemcount
        this.dishName = ItemdishName

        
      
      }));


    
    const obj2 :(Menu)= {
      dishName : this.dishName,
      cost:  this.cost,
      count :  this.count
     
      }

   
  this.getMenu(obj2)

  }


  public  getMenu(result: Menu): void{
 
    this.dialogs.getMenuItems()
    .subscribe( (shoppingItems: Menu[] )=> this.Menu = shoppingItems )

    this.addItem(result)

    }
    
    
   

  public addItem(result: Menu){
    this.dialogs.addItem(result)
    
  }  





}



  
  



