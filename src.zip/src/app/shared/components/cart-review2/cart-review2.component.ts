import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-review2',
  templateUrl: './cart-review2.component.html',
  styleUrls: ['./cart-review2.component.css']
})
export class CartReview2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
